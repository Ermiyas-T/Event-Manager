import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Event } from './event.entity';

@Injectable()
export class EventsService {
  constructor(
    @InjectRepository(Event)
    private eventRepository: Repository<Event>,
  ) {}

  // Create a new event
  create(event: Event): Promise<Event> {
    return this.eventRepository.save(event);
  }

  // Find all events
  findAll(): Promise<Event[]> {
    return this.eventRepository.find();
  }

  // Find an event by ID
  findOne(id: number): Promise<Event | null> {
    return this.eventRepository.findOne({ where: { id } });
  }

  // Update an event by ID
  async update(id: number, updateData: Partial<Event>): Promise<Event> {
    await this.eventRepository.update(id, updateData);
    const updatedEvent = await this.findOne(id);

    if (!updatedEvent) {
      throw new Error('Event not found');
    }

    return updatedEvent;
  }

  // Delete an event by ID
  async remove(id: number): Promise<void> {
    const eventToRemove = await this.findOne(id);

    if (!eventToRemove) {
      throw new Error('Event not found');
    }

    await this.eventRepository.remove(eventToRemove);
  }
}

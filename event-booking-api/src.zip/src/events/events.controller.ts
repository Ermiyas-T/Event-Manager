import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
} from '@nestjs/common';
import { EventsService } from './events.service';
import { Event } from './event.entity';

@Controller('events')
export class EventsController {
  constructor(private readonly eventService: EventsService) {}

  @Get()
  findAll(): Promise<Event[]> {
    return this.eventService.findAll();
  }
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<Event> {
    const event = await this.eventService.findOne(Number(id));
    if (!event) {
      throw new Error('Event not found');
    }
    return event;
  }
  @Post()
  create(@Body() event: Event): Promise<Event> {
    return this.eventService.create(event);
  }

  @Put(':id')
  update(@Param('id') id: number, @Body() event: Event): Promise<Event> {
    return this.eventService.update(id, event);
  }

  @Delete(':id')
  remove(@Param('id') id: number): Promise<void> {
    return this.eventService.remove(id);
  }
}

import { Entity, PrimaryGeneratedColumn, Column, BeforeInsert } from 'typeorm';
// import { IsNotEmpty, IsString, IsNumber, IsDateString } from 'class-validator'; // Avoid validation here

@Entity()
export class Event {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  title: string;

  @Column()
  description: string;

  @Column()
  date: string;

  @Column()
  location: string;

  @Column()
  price: number;

  // Constructor to ensure properties are initialized
  constructor(
    title: string,
    description: string,
    date: string,
    location: string,
    price: number,
  ) {
    this.title = title;
    this.description = description;
    this.date = date;
    this.location = location;
    this.price = price;
  }
}
